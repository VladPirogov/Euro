<?php
/**
 * Created by PhpStorm.
 * User: Влад
 * Date: 06.07.2018
 * Time: 15:08
 *
 * <input type="text" name="NameQ_Eng" method="POST" required pattern="[a-zA-Z]" value="<?php echo $row[0];?>">
 */
session_start();
include '../connection.php';
include 'upload.php';
include 'toWord.php';

if(isset($_POST['save'])){
    $NameQ_Eng="";
    if(!preg_match('/[^A-Za-z0-9]/',$_POST['NameQ_Eng']))
    {
        $NameQ_Eng=$_POST['NameQ_Eng'];
    }
    else{
       echo "<script> document.getElementById('NameQ_Eng').style.backgroundColor = 'red'; </script>";
    }

    $query=sprintf("UPDATE Qualification SET Qualification_EN = '%s'
    , Qualification_UA = '%s',  Degree ='%s',   abbreviation = '%s',
    FieldStudyUA = '%s', FieldStudyEN = '%s',FirstSpecialtyUA = '%s',
    FirstSpecialtyEN = '%s', SecondSpecialtyUA = '%s', SecondSpecialtyEN = '%s',
    SpecializationUA = '%s', SpecializationEN = '%s'
     WHERE User_ID = '".$_SESSION['user_id']."' AND Qualification_ID ='".$_SESSION["id_qualification"]."'",
        mysqli_real_escape_string($linc,$_POST['NameQ_Eng']),
        mysqli_real_escape_string($linc,$_POST['NameQ']),
        mysqli_real_escape_string($linc,$_POST['Degree']),
        mysqli_real_escape_string($linc,$_POST['abi']),
        mysqli_real_escape_string($linc,$_POST['FieldStudyUA']),
        mysqli_real_escape_string($linc,$_POST['FieldStudyEN']),
        mysqli_real_escape_string($linc,$_POST['FirstSpecialtyUA']),
        mysqli_real_escape_string($linc,$_POST['FirstSpecialtyEN']),
        mysqli_real_escape_string($linc,$_POST['SecondSpecialtyUA']),
        mysqli_real_escape_string($linc,$_POST['SecondSpecialtyEN']),
        mysqli_real_escape_string($linc,$_POST['SpecializationUA']),
        mysqli_real_escape_string($linc,$_POST['SpecializationEN'])
    );

    mysqli_query($linc,$query) or die(mysqli_error($linc));
           $query="UPDATE For_save
        SET Numberdisciplines = '".$_POST['text_num_2']."',
            Number_students = '".$_POST['text_num']."'
        WHERE Qualification_ID = '".$_SESSION['id_qualification']."'";
        mysqli_query($linc,$query) or die(mysqli_error($linc));
}
if(isset($_POST['toWord'])){

    Toword($_SESSION["id_qualification"]);
}

?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <title>Генератор єврододатків</title>
    <script type="text/javascript" src="../js/jquery.min.js"></script>
    <script type="text/javascript" src="../js/input.js"></script>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/style2addQuali.css" rel="stylesheet">
    <link rel="icon" href="../img/logo.png" type="image/x-icon">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
</head>
<body>
    <header id="header">
        <h2>
            <i>
                <p>Назва:
                    <span>
                    <?php
                        $query="SELECT
                                Qualification.Qualification_UA,
                                Qualification.abbreviation
                                FROM Qualification
                                WHERE Qualification.Qualification_ID =".$_SESSION["id_qualification"];
                        $result = mysqli_query($linc,$query) or die(mysqli_error($linc));
                        $row=mysqli_fetch_array($result,MYSQLI_NUM);
                        echo $row[0]." <p>".$row[1]."</p>";
                        $query="SELECT
                            Qualification.Qualification_EN,
                            Qualification.Qualification_UA,
                            Qualification.Degree,
                            Qualification.abbreviation,
                            Qualification.FieldStudyUA,
                            Qualification.FieldStudyEN,
                            Qualification.FirstSpecialtyUA,
                            Qualification.FirstSpecialtyEN,
                            Qualification.SecondSpecialtyUA,
                            Qualification.SecondSpecialtyEN,
                            Qualification.SpecializationUA,
                            Qualification.SpecializationEN
                        FROM Qualification
                        WHERE Qualification.User_ID = ".$_SESSION['user_id']."
                        AND Qualification.Qualification_ID =".$_SESSION["id_qualification"];
                        $result = mysqli_query($linc,$query) or die(mysqli_error($linc));
                        $row=mysqli_fetch_array($result,MYSQLI_NUM);
                    function selected( $value, $remember ){
                        return
                            $value == $remember ? 'selected' : null;
                    }
                        ?>
                    </span>
                </p>
            </i>
        </h2>
    </header>

    <div id="main" >
        <div class="flex-container-1">
            <div class="flex-element" id="menu" >
                <ul><li><a href="kabinet.php">Головна</a></li></ul>
                <ul>
                    <li><a href="addQualification.php">Здобута кваліфікація</a></li>
                    <li><a href="National_framework.php">Національна рамка</a></li>
                    <li><a href="Contents_and_results.php">Зміст та результати</a></li>
                    <li><a href="graduates.php">Список випускників</a></li>
                    <li><a href="Discipline.php">Дисципліни</a></li>
                    <li><a href="Estimates.php">Оцінки</a></li>
                </ul>
                <ul>

                    <li>

                        <form class="file_upload"
                              action="addQualification.php" method="POST" enctype="multipart/form-data" >
                            <div class="file_and_upload">
                                <label>
                                    <input type="file" name="file">
                                    <span>Оберіть файл</span>
                                </label>
                            </div>
                            <script>
                                $(document).ready( function() {
                                    $(".file_and_upload input[type=file]").change(function(){
                                        var filename = $(this).val().replace(/.*\\/, "");
                                        $("#filename").val(filename);
                                    });
                                });
                            </script>
                            <input type="text" id="filename" class="filename" disabled>
                            <button type="submit" name="UPLOAD" onclick="upload($linc)">Завантажити дані</button>
                        </form>
                    </li>
                    <li>
                        <form action="addQualification.php" method="post" >
                            <button type="submit" name="toWord" value="">Сформувати єврододатки</button>
                        </form>
                    </li>
                </ul>
            </div>
            <div class="flex-element" id="content">
                <form action="addQualification.php" method="POST">
                <div class="text_zone">
                    <p>Назва групи(Скорочено)</p>
                    <textarea name="abi" method="POST" required><?php echo $row[3];?></textarea>
                </div>
                <div class="text_zone">
                    <p>Ступінь освіти</p>
                    <select  name="Degree" method="POST" required>
                        <option value="Бакалавр" <?=selected("Бакалавр",$row[2] )?>>Бакалавр</option>
                        <option value="Магістр" <?=selected("Магістр",$row[2] )?>>Магістр</option>
                        <option value="Спеціаліст" <?=selected("Спеціаліст",$row[2] )?>>Спеціаліст</option>
                    </select>
                </div>
                <div class="text_zone">
                    <p>Кваліфікація</p>
                    <textarea name="NameQ" method="POST" required><?php echo $row[1];?></textarea>
                </div>
                <div class="text_zone">
                    <p>Qualification</p>
                    <textarea name="NameQ_Eng" method="POST" required ><?php echo $row[0];?></textarea>
                </div>
                <div class="text_zone">
                    <p>Галузь знань</p>
                    <textarea name="FieldStudyUA" method="POST"><?php echo $row[4];?></textarea>
                </div>
                <div class="text_zone">
                    <p>Field of study</p>
                    <textarea name="FieldStudyEN" method="POST" ><?php echo $row[5];?></textarea>
                </div>
                <div class="text_zone">
                     <p>Перша спеціальність</p>
                     <textarea name="FirstSpecialtyUA" method="POST" ><?php echo $row[6];?></textarea>
                </div>
                <div class="text_zone">
                     <p>First Specialty</p>
                     <textarea name="FirstSpecialtyEN" method="POST" ><?php echo $row[7];?></textarea>
                </div>
                <div class="text_zone">
                     <p>Друга спеціальність</p>
                     <textarea name="SecondSpecialtyUA" method="POST" ><?php echo $row[8];?></textarea>
                </div>
                <div class="text_zone">
                     <p>Second Specialty</p>
                     <textarea name="SecondSpecialtyEN" method="POST" ><?php echo $row[9];?></textarea>
                </div>
                <div class="text_zone">
                     <p>Спеціалізація</p>
                     <textarea name="SpecializationUA" method="POST" ><?php echo $row[10];?></textarea>
                </div>
                <div class="text_zone">
                     <p>Specialization</p>
                     <textarea name="SpecializationEN" method="POST" ><?php echo $row[11];?></textarea>
                </div>

                <div class="save" action='addQualification.php' method='post'>
                    <input type='submit'  name='save' value="Зберегти"/>
                </div>
                </form>
            </div>
        </div>
    </div>




</body>
</html>

<?php

?>
