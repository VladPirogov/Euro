<?php
/**
 * Created by PhpStorm.
 * User: Влад
 * Date: 01.10.2018
 * Time: 14:37
 */
session_start();
include '../connection.php';
function select($num)
{
    global $linc;
    $sql = "SELECT Teacher.* FROM Teacher";
    $result_select = mysqli_query($linc, $sql);
    ob_start();
    while($object = mysqli_fetch_object($result_select)){
        echo "<option value = '$object->Teacher_ID' <?=selected($object->Teacher_ID,$num )?> $object->Lastname </option>";}
    $res=ob_get_contents();
    ob_clean();
    return $res;
}
//$arr -
//$ard -

function ToBdGraduates($arr,$ard)
{
    $arrQ=array();
    global $linc;
    $queryINSERT="INSERT INTO graduates (Qualification_ID, Lastname_UA, Lastname_EN, Firstname_UA,
         Firstname_EN, birthday, SerialDiploma, NumberDiploma, NumberAddition, PrevDocument_UA,
          PrevDocument_EN, prevSerialNumberAddition, DurationOfTraining_UA, DurationOfTraining_EN, 
          TrainingStar, TrainingEnd, Actual_number_estimates, DecisionDate, ProtNum, QualificationAwardedUA,
           QualificationAwardedEN, IssuedBy)
        VALUES ";
    foreach ($arr as $row){
        if(($row[0]=="NaN")) {
            array_push($arrQ,"(" . $_SESSION["id_qualification"] . ", '"
                . $row[1] . "', '" . $row[2] . "', '" . $row[3] .
                "', '". $row[4] . "', '" . $row[5] .
                "', '" . $row[6] . "', '". $row[7].
                "', '". $row[8] . "', '" . $row[9] .
                "', '" . $row[10] . "', '".$row[11].
                "', '". $row[12] . "', '" .$row[13] .
                "', '" . $row[14]. "', '". $row[15].
                "', '". $row[16]. "', '" . $row[17] .
                "', '" . $row[18] . "', '". $row[19]."', '". $row[20]."' )");
        }elseif (($row[0] != "NaN")) {
            $queryUPDATE = "UPDATE graduates
                SET Lastname_UA = '" . $row[1] . "',
                    Lastname_EN = '" . $row[2] . "',
                    Firstname_UA = '" . $row[3] . "',
                    Firstname_EN = '" . $row[4] . "',
                    birthday = '" . $row[5] . "',
                    SerialDiploma = '" . $row[6] . "',
                    NumberDiploma = '" . $row[7] . "',
                    NumberAddition = '" . $row[8] . "',
                    PrevDocument_UA = '" . $row[9] . "',
                    PrevDocument_EN = '" . $row[10] . "',
                    prevSerialNumberAddition = '" . $row[11] . "',
                    DurationOfTraining_UA = '" . $row[12] . "',
                    DurationOfTraining_EN = '" . $row[13] . "',
                    TrainingStar = '" . $row[14] . "',
                    TrainingEnd = '" . $row[15] . "',
                    Actual_number_estimates = '" . $row[16] . "',
                    DecisionDate = '" . $row[17] . "',
                    ProtNum = '" . $row[18] . "',
                    QualificationAwardedUA = '" . $row[19] . "',
                    QualificationAwardedEN = '" . $row[20] . "',
                    IssuedBy = '" . $row[21] . "'
                WHERE Graduat_ID ='" . $row[0] . "'
                AND Qualification_ID =" . $_SESSION["id_qualification"];
            mysqli_query($linc,$queryUPDATE) or die(mysqli_error($linc));
        }
    }
    //print_r($ard);
    foreach ($ard as $row){
        //print_r($row);
        if (($row!= "NaN")) {
            $queryDel = "DELETE FROM graduates
            WHERE Graduat_ID = " . $row;
            print_r($queryDel);
            mysqli_query($linc, $queryDel) or die(mysqli_error($linc));
        }
    }
    //$query=$query.",";
    //print_r($queryINSERT);
    $queryINSERT=$queryINSERT.implode(",",$arrQ);
    mysqli_query($linc,$queryINSERT) or die(mysqli_error($linc));

    return true;
}

function ToBdDiscipline($arr,$ard)
{
    global $linc;
    $queryINSERT="INSERT INTO Discipline (Qualification_ID, Course_title_UA, Course_title_EN, Loans, Hours, Teaching, 
        Differential, Semester, Teacher_ID)
        VALUES ";
    foreach ($arr as $row){
        if(($row[0]=="NaN")) {
            $queryINSERT = $queryINSERT . "(" . $_SESSION["id_qualification"] . ", '"
                . $row[1] . "', '" . $row[2] . "', " . $row[3] . ", "
                . $row[4] . ", " . $row[5] . ", '" . $row[6] . "', "
                . $row[7] . ", " . $row[8] . ")";
            if ($row != end($arr)) {
                $queryINSERT = $queryINSERT . ",";
            }
        }elseif (($row[0] != "NaN")) {
                    $queryUPDATE = "UPDATE Discipline  SET Course_title_UA = '" . $row[1] . "',
                        Course_title_EN = '" . $row[2] . "',
                        Loans = " . $row[3] . ",
                        Hours = " . $row[4] . ",
                        Teaching = " . $row[5] . ",
                        Differential = '" . $row[6] . "'
                    WHERE Discipline_ID = '" . $row[0] . "'
                    AND Qualification_ID =" . $_SESSION["id_qualification"];
                mysqli_query($linc,$queryUPDATE) or die(mysqli_error($linc));
        }
    }
   // print_r($ard);
    foreach ($ard as $row){
        print_r($row);
        if (($row!= "NaN")){
        $queryDel=" DELETE FROM Discipline
          WHERE Discipline_ID = ".$row;
        //print_r($queryDel);
        mysqli_query($linc,$queryDel) or die(mysqli_error($linc));}
    }

    //$query=$query.",";
    //print_r($queryINSERT);
    mysqli_query($linc,$queryINSERT) or die(mysqli_error($linc));

    return true;
}

function ToBdEst($arr,$arrDisc,$arrG)
{
    /*$arrDisc= json_decode($arrDiscJson);
    $arrG= json_decode($arrGJson);*/
    /*$_POST['arrDisc']=json_encode($arrDiscJson);
    $_POST['arrG']=json_encode($arrGJson);*/
    print_r($arrDisc);
    print_r($arrG);
    global $linc;
    foreach (array_combine($arrG, $arr) as $id => $row)
    {
        $j=1;
        $qerIn="";
        $arrQuery=array();
        foreach($arrDisc as $i)
        {
            if($row[$j]>0){
                $Estim=$row[$j];
                if($row[$j-1]>0){
                    $DifUA="";$DifCH="";
                    if($i[1]=="Оцінка"){
                        if($Estim>=90){
                            $DifUA="Відмінно/Excellent";  $DifCH="A";
                        }elseif (($Estim>=80) && ($Estim<90)){
                            $DifUA="Добре/Good";$DifCH="B";
                        }elseif (($Estim>=71) && ($Estim<80)){
                            $DifUA="Добре/Good";$DifCH="C";
                        }elseif (($Estim>=61) && ($Estim<=70)){
                            $DifUA="Задовільно/Satisfactory";$DifCH="D";
                        }elseif (($Estim>=50) && ($Estim<=60)){
                            $DifUA="Задовільно/Satisfactory";$DifCH="E";
                        }else{
                            $DifUA="Не зараховано/Fail";$DifCH="F";
                        }
                    }else{
                        if(($Estim<=100) && ($Estim>50)){
                            $DifUA="Зараховано/Passed";
                            if($Estim>=90){
                                $DifCH="A";
                            }elseif (($Estim>=80) && ($Estim<90)){
                                $DifCH="B";
                            }elseif (($Estim>=71) && ($Estim<80)){
                                $DifCH="C";
                            }elseif (($Estim>=61) && ($Estim<=70)){
                                $DifCH="D";
                            }elseif (($Estim>=50) && ($Estim<=60)){
                                $DifCH="E";
                            }else{
                                $DifUA="Не зараховано/Fail";$DifCH="F";
                            }
                        }else {
                            $DifUA="Не зараховано/Fail";$DifCH="F";
                        }
                    }
                    $queryUPDATE = "UPDATE Estimates
                    SET Estimat_NUM = ".$Estim.",
                        Estimat_CHAR = ".$DifCH.",
                        Estimat_UA = ". $DifUA."
                    WHERE Disciptine_ID = ".$i[0]."
                    AND Graduat_ID =" . $id;
                    mysqli_query($linc,$queryUPDATE) or die(mysqli_error($linc));
                }else{
                    if($i[1]=="Оцінка"){
                        if($Estim>=90){
                            $DifUA="Відмінно/Excellent";  $DifCH="A";
                        }elseif (($Estim>=80) && ($Estim<90)){
                            $DifUA="Добре/Good";$DifCH="B";
                        }elseif (($Estim>=71) && ($Estim<80)){
                            $DifUA="Добре/Good";$DifCH="C";
                        }elseif (($Estim>=61) && ($Estim<=70)){
                            $DifUA="Задовільно/Satisfactory";$DifCH="D";
                        }elseif (($Estim>=50) && ($Estim<=60)){
                            $DifUA="Задовільно/Satisfactory";$DifCH="E";
                        }else{
                            $DifUA="Не зараховано/Fail";$DifCH="F";
                        }
                    }else{
                        if(($Estim<=100) && ($Estim>50)){
                            $DifUA="Зараховано/Passed";
                            if($Estim>=90){
                                $DifCH="A";
                            }elseif (($Estim>=80) && ($Estim<90)){
                                $DifCH="B";
                            }elseif (($Estim>=71) && ($Estim<80)){
                                $DifCH="C";
                            }elseif (($Estim>=61) && ($Estim<=70)){
                                $DifCH="D";
                            }elseif (($Estim>=50) && ($Estim<=60)){
                                $DifCH="E";
                            }else{
                                $DifUA="Не зараховано/Fail";$DifCH="F";
                            }
                        }else {
                            $DifUA="Не зараховано/Fail";$DifCH="F";
                        }

                    }
                    array_push($arrQuery, "('" . $id . "','".$i[0]. "','"
                        . $Estim . "', '" .$DifCH. "', '" . $DifUA . "')");
                }

            }

            $j+=2;
        }
        //printf($arrQuery);
        $query = "INSERT INTO Estimates (Graduat_ID, Disciptine_ID, Estimat_NUM, Estimat_CHAR, Estimat_UA) VALUES "
            .implode(",",$arrQuery);

    }
}

function check(){return true;}
?>