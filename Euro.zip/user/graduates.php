<?php

session_start();
include '../connection.php';
include 'functions_to_Bd.php';
if(isset($_POST['arrayOfTrValues'])|| isset($_POST['arrayOfTrValues'])){
    ToBdGraduates($_POST['arrayOfTrValues'],$_POST['arrToDel']);
    //header("Refresh: 0");
   // print_r($_POST['arrayOfTrValues']);
   // exit();
}
if(isset($_POST['toWord'])){

    Toword($_SESSION["id_qualification"]);
}

?>
<!DOCTYPE html>
<html lang="uk">
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

    <title>Генератор єврододатків</title>
    <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script type="text/javascript" src="../js/input.js"></script>
    <script type="text/javascript" src="../js/DynamicTableOld.js"></script>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">

    <link href="../css/discipline.css" rel="stylesheet">
    <link href="../css/grd.css" rel="stylesheet">
    <link href="../css/style2addQuali.css" rel="stylesheet">
    <link rel="icon" href="../img/logo.png" type="image/x-icon">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
</head>
<body>
<header id="header">
    <h2>
        <i>
            <p>Назва:
                <span>
                    <?php
                    $query="SELECT
                                Qualification.Qualification_UA,
                                Qualification.abbreviation
                                FROM Qualification
                                WHERE Qualification.Qualification_ID =".$_SESSION["id_qualification"];
                    $result = mysqli_query($linc,$query) or die(mysqli_error($linc));
                    $row=mysqli_fetch_array($result,MYSQLI_NUM);
                    echo $row[0]." <p> ".$row[1]."</p>";
                    $query="SELECT
                          Qualification.Qualification_EN,
                          Qualification.Qualification_UA,
                          Qualification.Main_field_study_UA,
                          Qualification.Main_field_study_EN,
                          Qualification.Degree,
                          Qualification.abbreviation
                        FROM Qualification
                        WHERE Qualification.User_ID = ".$_SESSION['user_id']."
                        AND Qualification.Qualification_ID =".$_SESSION["id_qualification"];
                    $result = mysqli_query($linc,$query) or die(mysqli_error($linc));
                    $row=mysqli_fetch_array($result,MYSQLI_NUM);
                    function selected( $value, $remember ){
                        return
                            $value == $remember ? 'selected' : null;
                    }
                    ?>
                    </span>
            </p>
        </i>
    </h2>
</header>

<div id="main" >
    <div class="flex-container-1">
        <div class="flex-element" id="menu" >
            <ul><li><a href="kabinet.php">Головна</a></li></ul>
            <ul>
                <li><a href="addQualification.php">Здобута кваліфікація</a></li>
                <li><a href="National_framework.php">Національна рамка</a></li>
                <li><a href="Contents_and_results.php">Зміст та результати</a></li>
                <li><a href="graduates.php">Список випускників</a></li>
                <li><a href="Discipline.php">Дисципліни</a></li>
                <li><a href="Estimates.php">Оцінки</a></li>
            </ul>
            <ul>
                <li>
                    <form class="file_upload"
                          action="graduates.php" method="POST" enctype="multipart/form-data" >
                        <div class="file_and_upload">
                            <label>
                                <input type="file" name="file">
                                <span>Оберіть файл</span>
                            </label>
                        </div>
                        <script>
                            $(document).ready( function() {
                                $(".file_and_upload input[type=file]").change(function(){
                                    var filename = $(this).val().replace(/.*\\/, "");
                                    $("#filename").val(filename);
                                });
                            });
                        </script>
                        <input type="text" id="filename" class="filename" disabled>
                        <button type="submit" name="UPLOAD" onclick="upload($linc)">Завантажити дані</button>
                    </form>
                </li>
                <li>
                    <form action="graduates.php" method="post" >
                        <button type="submit" name="toWord" value="">Сформувати єврододатки</button>
                    </form>
                </li>
            </ul>
        </div>
        <div class="flex-element" id="content">
            <div class="el">
                <table class="display-table" id="dynamic-table" border="1">

                    <thead>
                    <tr style="word-break: break-word">
                        <th scope="col">Прізвище</th>
                        <th scope="col">Family name(s)</th>
                        <th scope="col">Ім'я та по-батькові</th>
                        <th scope="col">Given name(s)</th>
                        <th scope="col">Дата нарождення</th>
                        <th scope="col">Серія діплома</th>
                        <th scope="col">Номер діплома</th>
                        <th scope="col">Номер додатка</th>
                        <th scope="col">Попередній документ про освіту</th>
                        <th scope="col">The previous document of education</th>
                        <th scope="col">Серія та номер <br> попереднього документу про освіту</th>
                        <th scope="col">Тривалість навчання</th>
                        <th scope="col">Duration of training</th>
                        <th scope="col">Початок навчання</th>
                        <th scope="col">Кінець навчання</th>
                        <th scope="col">Рішенням екзаменаційної комісії від</th>
                        <th scope="col">протокол №</th>
                        <th scope="col">присвоєно кваліфікацію</th>
                        <th scope="col">Qualification of </th>
                        <th scope="col">Ким виданий (навчальний заклад)</th>
                        <th scope="col" style="min-width: 70px">Додання/видалення строки</th>
                    </tr>
                    </thead>
                    <tbody id="dynamic">

                    <?php

                    $query="SELECT
                      graduates.Graduat_ID,
                      graduates.Lastname_UA,
                      graduates.Lastname_EN,
                      graduates.Firstname_UA,
                      graduates.Firstname_EN,
                      graduates.birthday,
                      graduates.SerialDiploma,
                      graduates.NumberDiploma,
                      graduates.NumberAddition,
                      graduates.PrevDocument_UA,
                      graduates.PrevDocument_EN,
                      graduates.prevSerialNumberAddition,
                      graduates.DurationOfTraining_UA,
                      graduates.DurationOfTraining_EN,
                      graduates.TrainingStar,
                      graduates.TrainingEnd,
                      graduates.DecisionDate,
                      graduates.ProtNum,
                      graduates.QualificationAwardedUA,
                      graduates.QualificationAwardedEN,
                      graduates.IssuedBy
                    FROM graduates
                    WHERE graduates.Qualification_ID =".$_SESSION["id_qualification"];
                    $result = mysqli_query($linc,$query) or die(mysqli_error($linc));
                    while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                        printf('
                    <form name="table" id="table" method="post">
                        
                            <tr CLASS="dynamicRow">
                                <td style="display: none">
                                    <input type="text" name="Graduat_ID" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="Lastname_UA" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="Lastname_EN" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="Firstname_UA" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="Firstname_EN" value="%s">
                                </td>
                                 <td>
                                    <input type="date" name="birthday" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="SerialDiploma" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="NumberDiploma" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="NumberAddition" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="PrevDocument_UA" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="PrevDocument_EN" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="prevSerialNumberAddition" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="DurationOfTraining_UA" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="DurationOfTraining_EN" value="%s">
                                </td>
                                <td>
                                    <input type="date" name="TrainingStar" value="%s">
                                </td>
                                <td>
                                    <input type="date" name="TrainingEnd" value="%s">
                                </td>
                                <td>
                                    <input type="date" name="DecisionDate" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="ProtNum" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="QualificationAwardedUA" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="QualificationAwardedEN" value="%s">
                                </td>
                                <td>
                                    <input type="text" name="IssuedBy" value="%s">
                                </td>
                                <td style="min-width: 70px">
                                    <button type="button" class="add">+</button>
                                    <button type="button" class="del">-</button>
                                </td>
                       
                            </tr>
                    </form>',$row[0],$row[1],$row[2],$row[3],$row[4],$row[5],$row[6],$row[7],$row[8],$row[9],$row[10],
                            $row[11],$row[12],$row[13],$row[14],$row[15],$row[16],$row[17],$row[18],$row[19],$row[20]);
                    }
                    ?>
                    <form name="table" method="post">
                        <tr CLASS="dynamicRow">
                            <td style="display: none">
                                <input type="text" name="Graduat_ID" value="NaN">
                            </td>
                            <td>
                                <input type="text" name="Lastname_UA" value="Lastname">
                            </td>
                            <td>
                                <input type="text" name="Lastname_EN" value="Lastname">
                            </td>
                            <td>
                                <input type="text" name="Firstname_UA" value="Firstname">
                            </td>
                            <td>
                                <input type="text" name="Firstname_EN" value="Firstname">
                            </td>
                            <td>
                                <input type="date" name="birthday" value="01.02.2001">
                            </td>
                            <td>
                                <input type="text" name="SerialDiploma" value="SerialDiploma">
                            </td>
                            <td>
                                <input type="text" name="NumberDiploma" value="NumberDiploma">
                            </td>
                            <td>
                                <input type="text" name="NumberAddition" value="NumberAddition">
                            </td>
                            <td>
                                <input type="text" name="PrevDocument_UA" value="PrevDocument">
                            </td>
                            <td>
                                <input type="text" name="PrevDocument_EN" value="PrevDocument">
                            </td>
                            <td>
                                <input type="text" name="prevSerialNumberAddition" value="prevSerialNumberAddition">
                            </td>
                            <td>
                                <input type="text" name="DurationOfTraining_UA" value="DurationOfTraining">
                            </td>
                            <td>
                                <input type="text" name="DurationOfTraining_EN" value="DurationOfTraining">
                            </td>
                            <td>
                                <input type="date" name="TrainingStar" value="TrainingStar">
                            </td>
                            <td>
                                <input type="date" name="TrainingEnd" value="TrainingEnd">
                            </td>
                            <td>
                                <input type="date" name="DecisionDate" value="01.02.2001">
                            </td>
                            <td>
                                <input type="text" name="ProtNum" value="ProtNum">
                            </td>
                            <td>
                                <input type="text" name="QualificationAwardedUA" value="QualificationAwardedUA">
                            </td>
                            <td>
                                <input type="text" name="QualificationAwardedEN" value="QualificationAwardedEN">
                            </td>
                            <td>
                                <input type="text" name="IssuedBy" value="IssuedBy">
                            </td>
                            <td style="min-width: 70px">
                                <button type="button" class="add">+</button>
                                <button type="button" class="del">-</button>
                            </td>
                        </tr>
                        <!--dynamicExample-->
                        <tr CLASS="dynamicRow" style="display: none">
                            <td style="display: none">
                                <input type="text" name="Graduat_ID" value="NaN">
                            </td>
                            <td>
                                <input type="text" name="Lastname_UA" value="Lastname">
                            </td>
                            <td>
                                <input type="text" name="Lastname_EN" value="Lastname">
                            </td>
                            <td>
                                <input type="text" name="Firstname_UA" value="Firstname">
                            </td>
                            <td>
                                <input type="text" name="Firstname_EN" value="Firstname">
                            </td>
                            <td>
                                <input type="date" name="birthday" value="01.02.2001">
                            </td>
                            <td>
                                <input type="text" name="SerialDiploma" value="SerialDiploma">
                            </td>
                            <td>
                                <input type="text" name="NumberDiploma" value="NumberDiploma">
                            </td>
                            <td>
                                <input type="text" name="NumberAddition" value="NumberAddition">
                            </td>
                            <td>
                                <input type="text" name="PrevDocument_UA" value="PrevDocument">
                            </td>
                            <td>
                                <input type="text" name="PrevDocument_EN" value="PrevDocument">
                            </td>
                            <td>
                                <input type="text" name="prevSerialNumberAddition" value="prevSerialNumberAddition">
                            </td>
                            <td>
                                <input type="text" name="DurationOfTraining_UA" value="DurationOfTraining">
                            </td>
                            <td>
                                <input type="text" name="DurationOfTraining_EN" value="DurationOfTraining">
                            </td>
                            <td>
                                <input type="date" name="TrainingStar" value="TrainingStar">
                            </td>
                            <td>
                                <input type="date" name="TrainingEnd" value="TrainingEnd">
                            </td>
                            <td>
                                <input type="date" name="DecisionDate" value="01.02.2001">
                            </td>
                            <td>
                                <input type="text" name="ProtNum" value="ProtNum">
                            </td>
                            <td>
                                <input type="text" name="QualificationAwardedUA" value="QualificationAwardedUA">
                            </td>
                            <td>
                                <input type="text" name="QualificationAwardedEN" value="QualificationAwardedEN">
                            </td>
                            <td>
                                <input type="text" name="IssuedBy" value="IssuedBy">
                            </td>
                            <td style="min-width: 70px">
                                <button type="button" class="add">+</button>
                                <button type="button" class="del">-</button>
                            </td>
                        </tr>
                    </tbody>
            </form >
            </table>
            </div>
            <form method="POST" action="graduates.php">
                <input type="submit" onclick="ParsTable()"  value="Зберегти" style="margin: 10px">
                <input  name="sub" type="hidden"  value="Зберегти" >
            </form>
        </div>

    </div>
</div>
<script>
    new DynamicTable( document.getElementById("dynamic") );
    //ParsTable();
</script>
</body>
</html>
