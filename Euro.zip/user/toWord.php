<?php

session_start();
include '../connection.php';
require '../vendor/autoload.php';
header('Content-Type: text/html; charset=utf-8');

//toword();

function Word($row,$folder,$IdQ)
{
    include '../connection.php';
    require '../vendor/autoload.php';


    //Загрузка шаблона
    $document =  new \PhpOffice\PhpWord\TemplateProcessor('Bachelor_Template.docx');
    //Вставка значений
    $document->setValue('SerialDiploma', $row[7]);
    $document->setValue('numberDiploma', $row[8]);
    $document->setValue('numberAddition', $row[9]);
    $document->setValue('lastname_UA', $row[2]);
    $document->setValue('lastname_EN', $row[3]);
    $document->setValue('firstname_UA', $row[4]);
    $document->setValue('firstname_EN', $row[5]);

    $document->setValue('birthday', date("d.m.Y",$row[6]));

    $document->setValue('qualification_UA', $row[25]);
    $document->setValue('qualification_EN', $row[24]);
    $document->setValue('FieldStudyUA', $row[32]);
    $document->setValue('FieldStudyEN', $row[33]);
    $document->setValue('FirstSpecialtyUA', $row[34]);
    $document->setValue('FirstSpecialtyEN', $row[35]);
    $document->setValue('SecondSpecialtyUA', $row[36]);
    $document->setValue('SecondSpecialtyEN', $row[37]);
    $document->setValue('SpecializationUA', $row[38]);
    $document->setValue('SpecializationEN', $row[39]);

    $document->setValue('durationProgram_UA', $row[54]);
    $document->setValue('durationProgram_EN', $row[55]);
    $document->setValue('accessRequiments_UA', $row[56]);
    $document->setValue('accessRequiments_EN', $row[57]);

    $document->setValue('modeStudy', $row[41]."/".$row[42]);
    $document->setValue('programSpecification_UA', $row[43]);
    $document->setValue('programSpecification_EN', $row[44]);

    $document->setValue('knowledgeUnderstanding_UA', $row[45]);
    $document->setValue('applyingKnowledge_UA', $row[47]);
    $document->setValue('MakingJudgments_UA', $row[49]);
    $document->setValue('quotas', $row[49]);

    $document->setValue('knowledgeUnderstanding_EN', $row[46]);
    $document->setValue('applyingKnowledge_EN', $row[48]);
    $document->setValue('MakingJudgments_EN', $row[50]);
    //$document->setValue('quotas', $row[50]);

    $document->setValue('Access_further_study_EN', $row[57]);
    $document->setValue('Access_further_study_UA', $row[58]);

    $document->setValue('Access_further_study_EN', $row[57]);
    $document->setValue('Access_further_study_UA', $row[58]);

    $document->setValue('Professional_status_UA', $row[60]);
    $document->setValue('Professional_status_EN', $row[61]);

    $document->setValue('DurationOfTraining_UA', $row[13]);
    $document->setValue('DurationOfTraining_EN', $row[14]);

    $document->setValue('TrainingStar', date("d.m.Y",$row[15]));
    $document->setValue('TrainingEnd', date("d.m.Y",$row[16]));

    $document->setValue('DecisionDate', date("d.m.Y",$row[18]));
    $document->setValue('ProtNum', $row[19]);

    $document->setValue('QualificationAwardedUA', $row[20]);
    $document->setValue('QualificationAwardedEN', $row[21]);

    $document->setValue('prevDocument_UA', $row[10]);
    $document->setValue('prevDocument_EN', $row[11]);

    $document->setValue('PrevSerialNumberAddition', $row[12]);
    $document->setValue('IssuedBy', $row[22]);

    //Оценки
    $numQne="SELECT
      Discipline.Course_title_UA,
      Discipline.Course_title_EN,
      Discipline.Loans,
      Discipline.Hours,
      Estimates.Estimat_NUM,
      Estimates.Estimat_CHAR,
      Estimates.Estimat_UA
    FROM Estimates
      INNER JOIN Discipline
        ON Estimates.Disciptine_ID = Discipline.Discipline_ID
    WHERE Estimates.Graduat_ID = '".$row[1]."'
    AND Discipline.Teaching = '1'
    ORDER BY Discipline.Course_title_UA";
    $numOneRes=mysqli_query($linc,$numQne) or die(mysqli_error($linc));
    $numRes=mysqli_num_rows($numOneRes);
    //print_r($numRes."</br>");



    $numTwo="SELECT
      Discipline.Course_title_UA,
      Discipline.Course_title_EN,
      Discipline.Loans,
      Discipline.Hours,
      Estimates.Estimat_NUM,
      Estimates.Estimat_CHAR,
      Estimates.Estimat_UA
    FROM Estimates
      INNER JOIN Discipline
        ON Estimates.Disciptine_ID = Discipline.Discipline_ID
    WHERE Discipline.Qualification_ID = '".$IdQ."'
    AND Estimates.Graduat_ID = '".$row[1]."'
    AND Discipline.Teaching = '2'
    ORDER BY Discipline.Course_title_UA";
    $numTwoRes=mysqli_query($linc,$numTwo) or die(mysqli_error($linc));
    $T=mysqli_num_rows($numTwoRes);
    if($T>0) {
        $numRes += $T;
        $numRes +=1;
    }


    $numTree="SELECT
      Discipline.Course_title_UA,
      Discipline.Course_title_EN,
      Discipline.Loans,
      Discipline.Hours,
      Estimates.Estimat_NUM,
      Estimates.Estimat_CHAR,
      Estimates.Estimat_UA
    FROM Estimates
      INNER JOIN Discipline
        ON Estimates.Disciptine_ID = Discipline.Discipline_ID
    WHERE Discipline.Qualification_ID = '".$IdQ."'
    AND Estimates.Graduat_ID = '".$row[1]."'
    AND Discipline.Teaching = '3'
    ORDER BY Discipline.Course_title_UA";
    $numTreeRes=mysqli_query($linc,$numTree) or die(mysqli_error($linc));
    $Tr=mysqli_num_rows($numTreeRes);
    if($Tr>0) {
        $numRes += $Tr;
        $numRes +=1;
    }


    $numF="SELECT
      Discipline.Course_title_UA,
      Discipline.Course_title_EN,
      Discipline.Loans,
      Discipline.Hours,
      Estimates.Estimat_NUM,
      Estimates.Estimat_CHAR,
      Estimates.Estimat_UA
    FROM Estimates
      INNER JOIN Discipline
        ON Estimates.Disciptine_ID = Discipline.Discipline_ID
    WHERE Discipline.Qualification_ID = '".$IdQ."'
    AND Estimates.Graduat_ID = '".$row[1]."'
    AND Discipline.Teaching = '4'
    ORDER BY Discipline.Course_title_UA";
    $numFRes=mysqli_query($linc,$numF) or die(mysqli_error($linc));
    $F=mysqli_num_rows($numFRes);
    if($F>0) {
        $numRes += $F;
        $numRes +=1;
    }

    $i=1;
    //Таблица
    $document->cloneRow('Course', $numRes);

    while ($rE = mysqli_fetch_array($numOneRes, MYSQLI_NUM)){
        $document->setValue('code#'.$i, $i);
        $document->setValue('Course#'.$i, $rE[0]."/".$rE[1]);
        $document->setValue('cred#'.$i, $rE[2]);
        $document->setValue('hrs#'.$i, $rE[3]);
        $document->setValue('mar#'.$i, $rE[4]);
        $document->setValue('National_grade#'.$i, $rE[6]);
        $document->setValue('gra#'.$i, $rE[5]);
        $i+=1;
    }

    if($T>0) {
        $document->setValue('code#'.$i, "");
        $document->setValue('Course#'.$i, "Практики/Practices");
        $document->setValue('cred#'.$i, "");
        $document->setValue('hrs#'.$i, "");
        $document->setValue('mar#'.$i, "");
        $document->setValue('National_grade#'.$i, "");
        $document->setValue('gra#'.$i, "");
        $i+=1;
        while ($rE2 = mysqli_fetch_array($numTwoRes, MYSQLI_NUM)) {
            $document->setValue('code#'.$i, ($i-1));
            $document->setValue('Course#'.$i, $rE2[0]."/".$rE2[1]);
            $document->setValue('cred#'.$i, $rE2[2]);
            $document->setValue('hrs#'.$i, $rE2[3]);
            $document->setValue('mar#'.$i, $rE2[4]);
            $document->setValue('National_grade#'.$i, $rE2[6]);
            $document->setValue('gra#'.$i, $rE2[5]);
            $i+=1;
        }
    }
    if($Tr>0) {
        $document->setValue('code#'.$i, "");
        $document->setValue('Course#'.$i, "Курсові роботи/Coursework");
        $document->setValue('cred#'.$i, "");
        $document->setValue('hrs#'.$i, "");
        $document->setValue('mar#'.$i, "");
        $document->setValue('National_grade#'.$i, "");
        $document->setValue('gra#'.$i, "");
        $i+=1;
        while ($rE3 = mysqli_fetch_array($numTreeRes, MYSQLI_NUM)) {
            $document->setValue('code#'.$i, ($i-2));
            $document->setValue('Course#'.$i, $rE3[0]."/".$rE3[1]);
            $document->setValue('cred#'.$i, $rE3[2]);
            $document->setValue('hrs#'.$i, $rE3[3]);
            $document->setValue('mar#'.$i, $rE3[4]);
            $document->setValue('National_grade#'.$i, $rE3[6]);
            $document->setValue('gra#'.$i, $rE3[5]);
            $i+=1;
        }
    }
    if ($F>0) {
        $document->setValue('code#'.$i, "");
        $document->setValue('Course#'.$i, "Державні атестації/State certification");
        $document->setValue('cred#'.$i, "");
        $document->setValue('hrs#'.$i, "");
        $document->setValue('mar#'.$i, "");
        $document->setValue('National_grade#'.$i, "");
        $document->setValue('gra#'.$i, "");
        $i+=1;
        while ($rE4 = mysqli_fetch_array($numFRes, MYSQLI_NUM)) {
            $document->setValue('code#'.$i, ($i-3));
            $document->setValue('Course#'.$i, $rE4[0]."/".$rE4[1]);
            $document->setValue('cred#'.$i, $rE4[2]);
            $document->setValue('hrs#'.$i, $rE4[3]);
            $document->setValue('mar#'.$i, $rE4[4]);
            $document->setValue('National_grade#'.$i, $rE4[6]);
            $document->setValue('gra#'.$i, $rE4[5]);
            $i+=1;
        }
    }



    //Сохранение документа в браузер

    $fileNameNew=$folder."/".$row[3].$row[5].$row[1].".docx";
    //print_r($fileNameNew."</br>");
    $document->saveAs($fileNameNew);
    //$document->saveAs($row[2].'.docx');
    //print_r($_SERVER["DOCUMENT_ROOT"]."/user/".$fileNameNew);
    return $fileNameNew;
}
function  Toword($IdQ)
{
    include '../connection.php';
    require '../vendor/autoload.php';
    $folder='uploads/'.date('lis').rand();
    mkdir($folder);
    $zip=new ZipArchive;
    $zip_name = time().".zip"; // имя файла
    $zip->open($zip_name,ZipArchive::CREATE);
    $query="SELECT   graduates.*,  Qualification.*,  Contents_and_results.*,  National_framework.* FROM graduates ".
        "INNER JOIN Qualification ON graduates.Qualification_ID = Qualification.Qualification_ID ".
        "INNER JOIN Contents_and_results ON Contents_and_results.Qualification_ID = Qualification.Qualification_ID ".
        "INNER JOIN National_framework  ON National_framework.Qualification_ID = Qualification.Qualification_ID ".
        "WHERE Qualification.Qualification_ID = '".$IdQ."' ";
    $result = mysqli_query($linc,$query) or die(mysqli_error($linc));
    for ($data =array();$row = mysqli_fetch_array($result, MYSQLI_NUM);$data=$row)
    {$zip->addFile(Word($row,$folder,$IdQ));}
    $zip->close();
    if(file_exists($zip_name)) {
        // отдаём файл на скачивание
        header('Content-type: application/zip');
        header('Content-Disposition: attachment; filename="' . $zip_name . '"');
        readfile($zip_name);
        // удаляем zip файл если он существует
        unlink($zip_name);
    }
    rrmdir($folder);
//    header("Content-Disposition: attachment; filename='".$row[2].".docx'");
//    readfile($temp_file); // or echo file_get_contents($temp_file);
//    unlink($temp_file);  // remove temp file
}
function rrmdir($src) {
    $dir = opendir($src);// Директория с файлами, открыть поток чтения из паки

    while(false !== ( $file = readdir($dir)) ) {// Прочёсываем директорию
        if (( $file != '.' ) && ( $file != '..' ) ) {
            $full = $src . '/' . $file;//Путь к папке
            if ( is_dir($full) ) {//Проверка на пустату папки
                rrmdir($full);
            }
            else {
                if (file_exists($full)){
                    unlink($full);//Удалить файл
                }
            }
        }
    }
    closedir($dir);//Закрытие потока
    if(strpos($src,"/")){ rmdir($src);}
}
?>