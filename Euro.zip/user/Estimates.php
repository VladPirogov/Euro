<?php
/**
 * Created by PhpStorm.
 * User: Влад
 * Date: 13.08.2018
 * Time: 10:40
 */
session_start();
include '../connection.php';
include 'functions_to_Bd.php';
include 'toWord.php';

if(isset($_POST['arrayOfTrValues'])|| isset($_POST['arrayOfTrValues'])){

    //ToBdEst($_POST['arrayOfTrValues'],$arrDisc,$arrG);

    //header("Refresh: 0");

}
if(isset($_POST['toWord'])){

    Toword($_SESSION["id_qualification"]);
}

$arrDisc= array();
$arrG= array();

?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
    <meta http-equiv="Pragma" content="no-cache" />
    <meta http-equiv="Expires" content="0" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Генератор єврододатків</title>
    <link href="../css/bootstrap.min.css" rel="stylesheet">
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/discipline.css" rel="stylesheet">
    <link href="../css/style2addQuali.css" rel="stylesheet">
    <link rel="icon" href="../img/logo.png" type="image/x-icon">
    <link rel="shortcut icon" href="../img/logo.png" type="image/x-icon">
    <script src="../js/jquery.min.js"></script>
    <script src="../js/DynamicTableOld.js"></script>
    <script type="text/javascript">

    </script>

</head>
<body>
<header id="header">
    <script src="../js/jquery-3.2.1.min.js"></script>
    <h2>
        <i>
            <p>Назва:
                <span>
                        <?php
                        $query="SELECT
                                    Qualification.Qualification_UA,
                                    Qualification.abbreviation
                                    FROM Qualification
                                    WHERE Qualification.Qualification_ID =".$_SESSION["id_qualification"];
                        $result = mysqli_query($linc,$query) or die(mysqli_error($linc));
                        $row=mysqli_fetch_array($result,MYSQLI_NUM);
                        echo $row[0]." <p> ".$row[1]."</p>";
                        $query="SELECT
                              Qualification.Qualification_EN,
                              Qualification.Qualification_UA,
                              Qualification.Main_field_study_UA,
                              Qualification.Main_field_study_EN,
                              Qualification.Degree,
                              Qualification.abbreviation
                            FROM Qualification
                            WHERE Qualification.User_ID = ".$_SESSION['user_id']."
                            AND Qualification.Qualification_ID =".$_SESSION["id_qualification"];
                        $result = mysqli_query($linc,$query) or die(mysqli_error($linc));
                        $row=mysqli_fetch_array($result,MYSQLI_NUM);

                        function selected( $value, $remember ){
                            return
                                $value == $remember ? 'selected' : null;
                        }

                        ?>
                    </span>
            </p>
        </i>
    </h2>
</header>
<div id="main">
    <div class="flex-container-1">
        <div class="flex-element" id="menu" >
            <form  action="Discipline.php" method="POST">
                <ul><li><a href="kabinet.php">Головна</a></li></ul>
                <ul>
                    <li><a href="addQualification.php">Здобута кваліфікація</a></li>
                    <li><a href="National_framework.php">Національна рамка</a></li>
                    <li><a href="Contents_and_results.php">Зміст та результати</a></li>
                    <li><a href="graduates.php">Список випускників</a></li>
                    <li><a href="Discipline.php">Дисципліни</a></li>
                    <li><a href="Estimates.php">Оцінки</a></li>
                </ul>
                <ul>

                    <li>

                        <form class="file_upload"
                              action="Estimates.php" method="POST" enctype="multipart/form-data" >
                            <div class="file_and_upload">
                                <label>
                                    <input type="file" name="file">
                                    <span>Оберіть файл</span>
                                </label>
                            </div>
                            <script>
                                $(document).ready( function() {
                                    $(".file_and_upload input[type=file]").change(function(){
                                        var filename = $(this).val().replace(/.*\\/, "");
                                        $("#filename").val(filename);
                                    });
                                });
                            </script>
                            <input type="text" id="filename" class="filename" disabled>
                            <button type="submit" name="UPLOAD" onclick="upload($linc)">Завантажити дані</button>
                        </form>
                    </li>
                    <li>
                        <form action="Estimates.php" method="post" >
                            <button type="submit" name="toWord" value="">Сформувати <br/> єврододатки</button>
                        </form>
                    </li>
                </ul>
            </form>
        </div>
        <div class="flex-element" id="content">
            <div class="el">
                <table class="display-table" id="dynamic-table" border="1">

                    <thead>
                    <tr>
                        <th scope="col" style="min-width: 70px">Студент</th>
                        <?php

                        $query="SELECT
                          Discipline.Discipline_ID,
                          Discipline.Course_title_UA,
                          Discipline.Differential
                        FROM Discipline
                        WHERE Discipline.Qualification_ID = ".$_SESSION["id_qualification"];
                        $result = mysqli_query($linc,$query) or die(mysqli_error($linc));
                        while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                            printf('<th scope="col" style="display: none">%s</th>
                        <th scope="col" colspan="4">%s</th>',$row[0],$row[1]);
                            array_push($arrDisc,[$row[0],$row[2]]);
                        }
                        ?>
                    </tr>
                    </thead>
                    <tbody id="dynamic">
                    <form name="table" method="post">
                        <!--dynamicExample-->
                        <?php
                            $query="SELECT
                              graduates.Graduat_ID,
                              graduates.Lastname_UA
                            FROM graduates
                            WHERE graduates.Qualification_ID =".$_SESSION["id_qualification"];
                            $result = mysqli_query($linc,$query) or die(mysqli_error($linc));
                            while ($row = mysqli_fetch_array($result, MYSQLI_NUM)) {
                                printf('<tr CLASS="dynamicRow" >
                                <td scope="col" style="display: none">%s</td>
                                <td scope="col">%s</td>',$row[0],$row[1]);
                                array_push($arrG,$row[0]);
                                foreach ($arrDisc as $idDis){
                                    $qEs="SELECT
                                      Estimates.Estimat_ID,
                                      Estimates.Estimat_NUM,
                                      Estimates.Estimat_CHAR,
                                      Estimates.Estimat_UA
                                    FROM Estimates
                                    WHERE Estimates.Graduat_ID = ".$row[0]."
                                    AND Estimates.Disciptine_ID = ".$idDis[0];
                                    $rEs = mysqli_query($linc,$qEs) or die('yy'.mysqli_error($linc));
                                    $Es = mysqli_fetch_array($rEs, MYSQLI_NUM);
                                    if($Es[1]==Null){$Es[1]==0;}
                                    printf('
                                    <td >
                                       <td style="display: none">
                                        <input type="text" name="G_ID" value="%s">
                                        </td>
                                        <td style="display: none">
                                        <input type="text" name="Disp_ID" value="%s">
                                        </td>
                                        <td style="display: none">
                                        <input type="text" name="Est_ID" value="%s">
                                        </td>
                                        <td><input type="number" name="Est" maxlength="3" min="0" max="100" style="max-width: 50px" value="%s"></td>
                                       <td><p>%s</p></td>
                                       <td><p style="min-width: 80px">%s</p></td>
                                    </td>',$row[0],$idDis[0],$Es[0],$Es[1],$Es[2],$Es[3]);
                                }
                            }
                            printf("</tr>");
                            //print_r($arrDisc);

                            ?>

                    </tbody>
                    </form >
                </table>
            </div>
            <form method="POST" action="Estimates.php">
                <input type="submit" onclick="ParsTableEst()"  value="Зберегти" style="margin: 10px">
                <input  name="sub" type="hidden"  value="Зберегти" >
            </form>
        </div>
    </div>

    <script>
        new DynamicTable( document.getElementById("dynamic") );
        //ParsTable();
    </script>
</body>

