<?php
/**
 * Created by PhpStorm.
 * User: Влад
 * Date: 07.08.2018
 * Time: 11:29
 */
header('Content-Type: text/html; charset=utf-8');
mb_internal_encoding ("utf-8");


require_once 'excel_reader2.php';//подключаем библиотеку
session_start();
include '../connection.php';

upload($linc);

function upload($linc)
{

    if (isset($_POST['UPLOAD'])) {//проверяем была ли отправлена форма
        $file = $_FILES['file'];

        $fileName = $_FILES['file']['name']; //имя файла у пользователя
        $fileTmpName = $_FILES['file']['tmp_name'];//временное имя файла которое присваивает сервер именно эту перемунную используем как
        //имя файла в библиотеке
        $fileSize = $_FILES['file']['size']; // размер файла
        $fileError = $_FILES['file']['error'];//ошибки при загрузке
        $fileType = $_FILES['file']['type'];//расшиsрение файла
        $fileExt = explode(".", $fileName); //получаем расширение файла
        $fileActualExt = strtolower(end($fileExt));//получаем расширение файла
        $allowed = array('xls');// тут в массиве указиваю допустимые расширеня файлов
        if (in_array($fileActualExt, $allowed)) {//проверка на то является ли расширение файла допустимым из массива
            if ($fileError == 0) {//проверка на наличие ошибок при загрузке
                if ($fileSize < 5000000) {//проверка на превышение размера файла
                    $data = new Spreadsheet_Excel_Reader($fileTmpName);// записываем все инфу файла в переменную
//ОТ сюда
                    if (Chek($data, 5)) {
                        $query = sprintf("UPDATE Qualification SET Qualification_EN = '%s',
                    Qualification_UA = '%s',  FieldStudyUA = '%s',  FieldStudyEN = '%s',
                    FirstSpecialtyUA = '%s', FirstSpecialtyEN = '%s',  SecondSpecialtyUA = '%s',
                    SecondSpecialtyEN = '%s', SpecializationUA = '%s', SpecializationEN = '%s',
                    Degree = '%s'
                     WHERE User_ID = '" . $_SESSION['user_id'] . "' AND Qualification_ID ='" . $_SESSION["id_qualification"] . "'",
                            mysqli_real_escape_string($linc, $data->val(2, 2, 1)),/*Анг*/
                            mysqli_real_escape_string($linc, $data->val(1, 2, 1)),/*кваликавали ция (ряд,столбец, лист)*/
                            mysqli_real_escape_string($linc, $data->val(3, 2, 1)),/*Галузь зна*/
                            mysqli_real_escape_string($linc, $data->val(4, 2, 1)),/*Анг*/
                            mysqli_real_escape_string($linc, $data->val(5, 2, 1)),/*Перша спеціальнисть*/
                            mysqli_real_escape_string($linc, $data->val(6, 2, 1)),/*Анг*/
                            mysqli_real_escape_string($linc, $data->val(7, 2, 1)),/*Друга спеціальнисть*/
                            mysqli_real_escape_string($linc, $data->val(8, 2, 1)),/*Анг*/
                            mysqli_real_escape_string($linc, $data->val(9, 2, 1)),/*Спеціалізац*/
                            mysqli_real_escape_string($linc, $data->val(10, 2, 1)),
                            mysqli_real_escape_string($linc, $data->val(11, 2, 1))/*Ступинь*/
                        );
                        mysqli_query($linc, $query) or die(mysqli_error($linc));
                        $query = sprintf("UPDATE National_framework
                    SET Level_qualification_UA = '%s', Level_qualification_EN = '%s', Official_duration_programme_UA = '%s',
                        Official_duration_programme_EN = '%s', Access_requirements_UA = '%s', Access_requirements_EN = '%s',
                        Access_further_study_UA = '%s', Access_further_study_EN = '%s', Professional_status_UA = '%s',
                        Professional_status_EN = '%s'
                    WHERE  Qualification_ID ='" . $_SESSION["id_qualification"] . "'",
                            mysqli_real_escape_string($linc, $data->val(1, 2, 2)),
                            mysqli_real_escape_string($linc, $data->val(2, 2, 2)),/*Анг*/
                            mysqli_real_escape_string($linc, $data->val(3, 2, 2)),/*Оф тривалість*/
                            mysqli_real_escape_string($linc, $data->val(4, 2, 2)),/*Анг*/
                            mysqli_real_escape_string($linc, $data->val(5, 2, 2)),/*Вімога до вступу*/
                            mysqli_real_escape_string($linc, $data->val(6, 2, 2)),/*Анг*/
                            mysqli_real_escape_string($linc, $data->val(7, 2, 2)),/*Академічні права*/
                            mysqli_real_escape_string($linc, $data->val(8, 2, 2)),/*Анг*/
                            mysqli_real_escape_string($linc, $data->val(9, 2, 2)),/*Професійні права*/
                            mysqli_real_escape_string($linc, $data->val(10, 2, 2))
                        );
                        mysqli_query($linc, $query) or die(mysqli_error($linc));
                        $query = sprintf("UPDATE Contents_and_results
                    SET Form_study_UA = '%s', Form_study_EN = '%s', Program_Specification_UA = '%s',
                        Program_Specification_EN = '%s', Knowledge_undestanding_UA = '%s', Knowledge_undestanding_EN = '%s',
                        Application_knowledge_understanding_UA = '%s', Application_knowledge_understanding_EN = '%s',
                        Making_judgments_UA = '%s', Making_judgments_EN = '%s'
                    WHERE  Qualification_ID ='" . $_SESSION["id_qualification"] . "'",
                            mysqli_real_escape_string($linc, substr($data->val(2, 1, 3), 0, strpos($data->val(2, 1, 3), "/")+1)),
                            mysqli_real_escape_string($linc, substr($data->val(2, 1, 3), strpos($data->val(2, 1, 3), "/")+1)),/*Анг*/
                            mysqli_real_escape_string($linc, ToOneStr($data, 2, 3)),/**/
                            mysqli_real_escape_string($linc, ToOneStr($data, 3, 3)),/*Оф тривалість*/
                            mysqli_real_escape_string($linc, ToOneStr($data, 4, 3)),/*Анг*/
                            mysqli_real_escape_string($linc, ToOneStr($data, 5, 3)),/*Вімога до вступу*/
                            mysqli_real_escape_string($linc, ToOneStr($data, 6, 3)),/*Анг*/
                            mysqli_real_escape_string($linc, ToOneStr($data, 7, 3)),/*Академічні права*/
                            mysqli_real_escape_string($linc, ToOneStr($data, 8, 3)),/*Анг*/
                            mysqli_real_escape_string($linc, ToOneStr($data, 9, 3))
                        );
                        mysqli_query($linc, $query) or die(mysqli_error($linc));

                        //Cleaner();
                        $queryDel="DELETE
                          FROM Discipline
                        WHERE Qualification_ID=".$_SESSION["id_qualification"];
                        //print_r($queryDel);
                        mysqli_query($linc,$queryDel) or die(mysqli_error($linc));
                        $queryDel="DELETE
                          FROM graduates
                        WHERE Qualification_ID=".$_SESSION["id_qualification"];
                        //print_r($queryDel);
                        mysqli_query($linc,$queryDel) or die(mysqli_error($linc));

                        Students($linc,$data);

                        $queryINSERT = "INSERT INTO Discipline (Qualification_ID, Course_title_UA, Course_title_EN, Loans, Hours, Teaching, 
                        Differential) VALUES ";
                        $rowcount = $data->rowcount(5);
                        for ($i = 2; $i <= $rowcount; $i++) {
                            $queryINSERT = $queryINSERT . "(" . $_SESSION["id_qualification"] . ", '"
                                . mysqli_real_escape_string($linc,$data->val($i, 1, 5)) . "', '" . mysqli_real_escape_string($linc,$data->val($i, 2, 5))
                                . "', " . mysqli_real_escape_string($linc,$data->val($i, 3, 5)) . ", "
                                . mysqli_real_escape_string($linc,$data->val($i, 4, 5)) . ", " . mysqli_real_escape_string($linc,$data->val($i, 5, 5) ). ", '" . $data->val($i, 6, 5) . "' )";
                            if ($i != $rowcount) {
                                $queryINSERT = $queryINSERT . ",";
                            }
                        }
                        mysqli_query($linc, $queryINSERT) or die(mysqli_error($linc));
                        Estimates($_SESSION["id_qualification"], $linc, $data);
                    } else {
                        echo "There is an error in the design of the document";
                    }
//До сюда
                } else {
                    echo "Your file is too big!";
                }

            } else {
                echo "There was an error uploading your file!";
            }
        } else {
            echo "You cannot upload this file";
        }
    }
}
function Chek($sheets,$num){
    if(count($sheets->sheets)== ($num)){
        return true;
    }
    return true;
}

function ToOneStr($dt,$col,$sht){
    //exel_reder2 строка с 390 по 395
    $rowcount=$dt->rowcount($sht);
    $Allstr="";
    for($i=2;$i<=$rowcount;$i++){
        if(($dt->val($i,$col,$sht))!= null){
            $Allstr=$Allstr.$dt->val($i,$col,$sht).";";
        }
    }
    return $Allstr;

}
function Estimates($id_Q,$linc,$data){
    $queryDic="SELECT
          Discipline.Discipline_ID,
          Discipline.Differential
        FROM Discipline
        WHERE Discipline.Qualification_ID ='" . $_SESSION["id_qualification"] . "'";

    $query="SELECT
      graduates.Graduat_ID
    FROM graduates
    WHERE graduates.Qualification_ID = ".$id_Q;
    $rGraduat=mysqli_query($linc,$query) or die(mysqli_error($linc));
    $i=3;
    $arrQuery=array();
    foreach (mysqli_fetch_all($rGraduat,MYSQLI_NUM) as $Gra){
        $j=2;
        //print_r($Gra);
        //print_r("I->".$i."\==/". $j."<-J");
        $rDiscipline=mysqli_query($linc,$queryDic) or die(mysqli_error($linc));
        foreach  (mysqli_fetch_all($rDiscipline,MYSQLI_NUM) as $Disc){
            $Estim=$data->val($i, $j, 4);
            if($Estim==0){ continue;}
            $DifUA="";$DifCH="";

            if($Disc[1]=="Оцінка"){
                if($Estim>=90){
                    $DifUA="Відмінно/Excellent";  $DifCH="A";
                }else{
                    if (($Estim>=80) && ($Estim<90)){
                        $DifUA="Добре/Good";$DifCH="B";
                    }else{
                        if (($Estim>=71) && ($Estim<80)){
                        $DifUA="Добре/Good";$DifCH="C";
                        }else{
                            if (($Estim>=61) && ($Estim<=70)){
                                $DifUA="Задовільно/Satisfactory";$DifCH="D";
                            }else{
                                if (($Estim>=50) && ($Estim<=60)){
                                    $DifUA="Задовільно/Satisfactory";$DifCH="E";
                                }else{
                                    $DifUA="Не зараховано/Fail";$DifCH="F";
                                }
                            }
                        }
                    }
                }
            }else{
                if(($Estim<=100) && ($Estim>=50)){
                    $DifUA="Зараховано/Passed";
                    if($Estim>=90){
                        $DifCH="A";
                    }elseif (($Estim>=80) && ($Estim<90)){
                        $DifCH="B";
                    }elseif (($Estim>=71) && ($Estim<80)){
                       $DifCH="C";
                    }elseif (($Estim>=61) && ($Estim<=70)){
                        $DifCH="D";
                    }elseif (($Estim>=50) && ($Estim<=60)){
                       $DifCH="E";
                    }else{
                        $DifUA="Не зараховано/Fail";$DifCH="F";
                    }
                }else {
                    $DifUA="Не зараховано/Fail";$DifCH="F";
                }
            }
                array_push($arrQuery, "('" .$Gra[0] . "','".$Disc[0]. "','"
                    . $Estim . "', '" .$DifCH. "', '" . $DifUA . "')");
            $j+=3;
        }
        $i+=1;

    }

    $query = "INSERT INTO Estimates (Graduat_ID, Disciptine_ID, Estimat_NUM, Estimat_CHAR, Estimat_UA) VALUES "
        .implode(",",$arrQuery);
    mysqli_query($linc,$query) or die(mysqli_error($linc));
    return $query;
}
function Students($linc,$data){

    $arrQ=array();
    $query="INSERT INTO graduates (Qualification_ID, Lastname_UA, Lastname_EN, Firstname_UA,
         Firstname_EN, birthday, SerialDiploma, NumberDiploma, NumberAddition, PrevDocument_UA,
          PrevDocument_EN, prevSerialNumberAddition, DurationOfTraining_UA, DurationOfTraining_EN, 
          TrainingStar, TrainingEnd, Actual_number_estimates, DecisionDate, ProtNum, QualificationAwardedUA,
           QualificationAwardedEN, IssuedBy)
        VALUES ";
    $rowcount = $data->rowcount(0);
    for ($i = 2; $i <= $rowcount; $i++) {
        array_push($arrQ,"(" . $_SESSION["id_qualification"] . ", '"
            . mysqli_real_escape_string($linc,$data->val($i, 1, 0)) . "', '" . mysqli_real_escape_string($linc,$data->val($i, 2, 0))
            . "', '" . mysqli_real_escape_string($linc,$data->val($i, 3, 0)) ."', '". mysqli_real_escape_string($linc,$data->val($i, 4, 0))
            . "', '" . mysqli_real_escape_string($linc,$data->val($i, 5, 0)) ."', '" . mysqli_real_escape_string($linc,$data->val($i, 6, 0))
            . "', '". mysqli_real_escape_string($linc,$data->val($i, 7, 0)).
            "', '". mysqli_real_escape_string($linc,$data->val($i, 8, 0)) . "', '" .mysqli_real_escape_string($linc, $data->val($i, 9, 0)) .
            "', '" . mysqli_real_escape_string($linc,$data->val($i, 10, 0)) . "', '". mysqli_real_escape_string($linc,$data->val($i, 11, 0)).
            "', '". mysqli_real_escape_string($linc,$data->val($i, 12, 0)) . "', '" . mysqli_real_escape_string($linc,$data->val($i, 13, 0)) .
            "', '" . mysqli_real_escape_string($linc,$data->val($i, 14, 0) ). "', '". mysqli_real_escape_string($linc,$data->val($i, 15, 0)).
            "', '". mysqli_real_escape_string($linc,$data->val($i, 16, 0) ). "', '" . mysqli_real_escape_string($linc,$data->val($i, 17, 0)) .
            "', '" . mysqli_real_escape_string($linc,$data->val($i, 18, 0)) . "', '". mysqli_real_escape_string($linc,$data->val($i, 19, 0)).
            "', '". mysqli_real_escape_string($linc,$data->val($i, 20, 0))."', '". mysqli_real_escape_string($linc,$data->val($i, 21, 0))."' )");
    }
    $query=$query.implode(",",$arrQ);
    mysqli_query($linc, $query) or die(mysqli_error($linc));
}
function Cleaner(){
    $queryDel="DELETE
                  FROM Discipline
                WHERE Qualification_ID ".$_SESSION["id_qualification"];
    //print_r($queryDel);
    mysqli_query($linc,$queryDel) or die(mysqli_error($linc));
    $queryDel="DELETE
                  FROM graduates
                WHERE Qualification_ID ".$_SESSION["id_qualification"];
    //print_r($queryDel);
    mysqli_query($linc,$queryDel) or die(mysqli_error($linc));
}
?>