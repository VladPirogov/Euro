
var arrToDel=[];
function ParsTable() {
    //Объект таблицы в DOM
    var table = $('#dynamic-table');

    //Объекты всех строк таблицы
    var rows = table.children().children();

    //Массив соответствующий строкам таблицы
    var arrayOfTrValues = [];
    //Перебор строк (DOM-элементы)
    for (var rowI = 0; rowI < (rows.length-1); rowI++) {
        //Объект, соответсвующий содержимому одной строки
        arrayOfTrValues[rowI]=[];
        //Ячейки текущей строки (DOM-элемент)
        var tr = $(rows[rowI]).children();
        //Перебор ячеек (DOM-элементы)
        for (var trI = 0; trI < tr.length; trI++) {
            //console.log(tr[trI].valueOf());
            if ($(tr[trI]).children().is("input")){ arrayOfTrValues[rowI].push( $(tr[trI]).children().val());}
            else{arrayOfTrValues[rowI].push( $(tr[trI]).children().children().val());}
        }
    }
    console.log('../user'+document.URL.substr(document.URL.lastIndexOf('/')));
    $.ajax({
        url:'../user'+document.URL.substr(document.URL.lastIndexOf('/')),
        type:'POST',
        data:{arrayOfTrValues: arrayOfTrValues, arrToDel: arrToDel},
        success: function (date){console.log(date)}
    });
}
function ParsTableEst() {
    //Объект таблицы в DOM
    var table = $('#dynamic-table');

    //Объекты всех строк таблицы
    var rows = table.children().children();

    //Массив соответствующий строкам таблицы
    var arrayOfTrValues = [];
    //Перебор строк (DOM-элементы)
    for (var rowI = 1; rowI < (rows.length-1); rowI++) {
        //Объект, соответсвующий содержимому одной строки

        //Ячейки текущей строки (DOM-элемент)
        var tr = $(rows[rowI]).children();
        //Перебор ячеек (DOM-элементы)
        for (var trI = 0; trI < tr.length; trI++) {
            //console.log(tr[trI].valueOf());
             //arrayOfTrValues[rowI].push( $(tr[trI]).children().val());
            //console.log($(tr[trI]).children().val());
            arrayOfTrValues[rowI]=[];
            var td=$(tr[trI]).children();
            for (var tdI = 0; tdI < td.length; tdI++)
            {
                //arrayOfTrValues[rowI][trI][tdI].push( $(td[tdI]).children().val());
                console.log($(td[tdI]).val());
                console.log($(td[tdI]).valueOf());
            }
        }
    }
    console.log('../user'+document.URL.substr(document.URL.lastIndexOf('/')));
    $.ajax({
        url:'../user'+document.URL.substr(document.URL.lastIndexOf('/')),
        type:'POST',
        data:{arrayOfTrValues: arrayOfTrValues, arrToDel: arrToDel},
        success: function (date){console.log(date)}
    });
}



var RID = 0;

var DynamicTable = (function(GLOB) {

    return function(tBody) {
        if (!(this instanceof arguments.callee)) {
            return new arguments.callee.apply(arguments);//конструктор
        }

        tBody.onclick = function(e) {
            var evt = e || GLOB.event,//события
                trg = evt.target || evt.srcElement;//ОБРАШЕНИЕ к вложенему елементу на котором было вызвано событеэ
            if (trg.className && trg.className.indexOf("add") !== -1) {
                _addRow(trg.parentNode.parentNode, tBody);//ФУнкция добавления строки
            } else if (trg.className && trg.className.indexOf("del") !== -1) {
                tBody.rows.length > 1 && _delRow(trg.parentNode.parentNode, tBody);//Функция удаления
                console.log(trg.parentNode.parentNode.getElementsByTagName("td")[0].getElementsByTagName("input")[0].value);
                arrToDel.push(trg.parentNode.parentNode.getElementsByTagName("td")[0].getElementsByTagName("input")[0].value);
            }
        };

        var el=document.getElementsByClassName("dynamicRow");
        var _rowTpl = el[el.length-1].cloneNode(true);//Получает первую строку и создайот ее точную копию
        _rowTpl.style.display='table-row';
        var _correctNames = function(row) {
            var elements = row.getElementsByTagName("tr");//возвращает массив, содержащий ссылки на все элементы указанного типа, находящиеся в HTML-документе.
            for (var i = 0; i < elements.length; i += 1) {
               if (elements.item(i).name) {//Метод item возвращает текущий элемент
                    if (elements.item(i).type &&
                        elements.item(i).type === "text" &&
                        elements.item(i).className &&
                        elements.item(i).className.indexOf("glob") !== -1) {
                        elements.item(i).value = RID;
                        console.log( elements.item(i).className.indexOf("glob"));
                    } else {
                        console.log(elements.item(i).name);
                        elements.item(i).name = RID + "[" + elements.item(i).name + "]";
                    }

                }
            }
            RID++;
            return row;
        };
        var _addRow = function(before, tBody) {
            var newNode = _correctNames(_rowTpl.cloneNode(true));
            newNode.style.display="bloc";
            tBody.insertBefore(newNode, before.nextSibling);// добавляет узел (element) в список дочерних элементов указанного родителя перед указанным узлом (element).
        };
        var _delRow = function(row, tBody) {
            tBody.removeChild(row);//Удаляет дочерний элемент из DOM. Возвращает удаленный элемент.

        };
        _correctNames(tBody);
    };
})(this);





//  new DynamicTable(document.getElementById("dynamic"));