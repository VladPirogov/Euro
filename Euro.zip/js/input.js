<script>
function myFunction()
{

    if (confirm("Choose Yes or Not"))
    {
        alert("You pressed OK!");
    <?php upload($linc);?>
        //тут удаление записи из базы
    }
    else
    {
        alert("You pressed Cancel!");
        //тут просто остаемся на странице
    }

}
</script>
