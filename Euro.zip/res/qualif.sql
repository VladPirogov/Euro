﻿SELECT 
  Qualification.Date,
  Qualification.abbreviation,
  Qualification.Qualification_UA
FROM Qualification
WHERE Qualification.User_ID = 1