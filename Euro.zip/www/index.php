<?php
/**
 * Created by PhpStorm.
 * User: Влад
 * Date: 20.06.2018
 * Time: 12:04
 */

include 'template/constants.inc';
echo $my;
?>